﻿document.addEventListener("DOMContentLoaded", () => {
    const navbarToggle = document.getElementById("navbarToggle");
    const navbarLinks = document.getElementById("navbarLinks");

    navbarToggle.addEventListener("click", () => {
        navbarLinks.classList.toggle("show");
    });
});